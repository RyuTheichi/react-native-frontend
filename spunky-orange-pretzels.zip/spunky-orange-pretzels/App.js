import React, { useState } from 'react';
import { StyleSheet, Text, View, ScrollView, Button } from 'react-native';
import { BarChart, PieChart } from "react-native-chart-kit";
import { Dimensions } from 'react-native';
import api from './services/src/api';

export default function App() {
  const screenWidth = Dimensions.get("window").width;

  const [QTD_ocorrencia, setQTD_ocorrencia] = useState({
    labels: ["Incidentes", "Requisições"],
    datasets: [
      {
        data: [30, 70]
      }
    ]
  });

  const [QTD_chamados, setQTD_chamados] = useState([
    { name: "Equipe A", count: 40, color: "#006400", legendFontColor: "#7F7F7F", legendFontSize: 15 },
    { name: "Equipe B", count: 30, color: "#228B22", legendFontColor: "#7F7F7F", legendFontSize: 15 },
    { name: "Equipe C", count: 20, color: "#32CD32", legendFontColor: "#7F7F7F", legendFontSize: 15 }
  ]);

  const fetchDataFromBackend = async () => {
    try {
      const response = await api.get(`/process_data/json/`);
      const { incidentesRequisicoes, rankEquipes } = response.data;

      setQTD_ocorrencia({
        labels: ["Incidentes", "Requisições"],
        datasets: [
          {
            data: incidentesRequisicoes
          }
        ]
      });

      setQTD_chamados(rankEquipes);
    } catch (error) {
      console.error('Erro ao buscar dados:', error);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Dashboard</Text>
      
      <Button title="Atualizar Dados" onPress={fetchDataFromBackend} />

      <Text style={styles.chartTitle}>Incidentes vs Requisições</Text>
      <BarChart
        style={styles.chart}
        data={QTD_ocorrencia}
        width={screenWidth - 25}
        height={220}
        chartConfig={chartConfig}
        verticalLabelRotation={0}
      />
      
      <Text style={styles.chartTitle}>Top 3 Equipes com Mais Chamados</Text>
      <PieChart
        data={QTD_chamados}
        width={screenWidth - 40}
        height={220}
        chartConfig={chartConfig}
        accessor="count"
        backgroundColor="transparent"
        paddingLeft="15"
      />
    </ScrollView>
  );
}

const chartConfig = {
  backgroundGradientFrom: "#1E2923",
  backgroundGradientFromOpacity: 0,
  backgroundGradientTo: "#08130D",
  backgroundGradientToOpacity: 0.5,
  color: (opacity = 1) => `rgba(0, 100, 0, ${opacity})`,
  strokeWidth: 2,
  barPercentage: 0.5,
  useShadowColorFromDataset: false
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#006400',
  },
  chartTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 10,
    color: '#006400',
  },
  chart: {
    marginVertical: 8,
    borderRadius: 16
  }
});